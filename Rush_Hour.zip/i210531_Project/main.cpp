//============================================================================
// Name        : .cpp
// Author      : FAST CS Department
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Rush Hour...
//============================================================================

//============================================================================
//                    				Submitted by
// Name : Haris Sohail
// Roll No: 21I-0531
// Class : BCS - 213D
// Assingment : Project
// ===========================================================================

#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include<string>
#include<cstdlib>
#include<ctime>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}

// Dividing the rows and columns of the 20x20 box into small equal boxes of 30x30 dimensions

int rows[20] , cols[20] , n = 180 , m = 610; //n and m represent the x and y dimensions

// x1 , y1 coordinates for the cars

int xI = 180, yI = 610; 

int car1_xI = 240 , car1_yI = 610;

int car2_xI = 180 , car2_yI = 40;

int car3_xI = 480 , car3_yI = 155;

int car4_xI = 545 , car4_yI = 380;

int car5_xI = 390 , car5_yI = 380;

// Making 2D arrays to store coordinates of the black boxes. A max of 20x20 boxes can be stored. 
unsigned short int x1[20][20] , Y1[20][20] , x2[20][20] , y2[20][20]; 

// Making 2D arrays to store coordinates of the trees. A max of 20x20 trees can be stored

unsigned short int tree_x1[20][20] , tree_Y1[20][20] , tree_x2[20][20] , tree_y2[20][20];

//  Making 2D arrays to store coordinates of the trees. A max of 20x20 passengers can be stored

unsigned short int pass_x1[20][20] , pass_Y1[20][20] , pass_x2[20][20] , pass_y2[20][20];

//============================================
// Name : drawTaxi
// Return : none
// Param : none
// Description : draws a yellow colored taxi
//============================================

void drawTaxi() {
	DrawSquare(xI, yI, 30, colors[YELLOW]); // body of the taxi

	//tyres
	DrawCircle(xI + 5 , yI + 5 , 5 , colors[BROWN]);
	DrawCircle(xI + 25 , yI + 25 , 5 , colors[BROWN]);
	DrawCircle(xI + 5 , yI + 25 , 5 , colors[BROWN]);
	DrawCircle(xI + 25 , yI + 5 , 5 , colors[BROWN]);
	glutPostRedisplay();
}

//============================================
// Name : drawcar_1
// Return : none
// Param : none
// Description : draws a car
//============================================

void drawcar_1()
{
	DrawSquare(car1_xI, car1_yI, 30, colors[MAGENTA]); // body of the car

	//tyres
	DrawCircle(car1_xI + 5 , car1_yI + 5 , 5 , colors[BROWN]);
	DrawCircle(car1_xI + 25 , car1_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car1_xI + 5 , car1_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car1_xI + 25 , car1_yI + 5 , 5 , colors[BROWN]);
	glutPostRedisplay();
}

//============================================
// Name : drawcar_2
// Return : none
// Param : none
// Description : draws a car
//============================================

void drawcar_2()
{
	DrawSquare(car2_xI, car2_yI, 30, colors[BLUE]); // body of the car

	//tyres
	DrawCircle(car2_xI + 5 , car2_yI + 5 , 5 , colors[BROWN]);
	DrawCircle(car2_xI + 25 , car2_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car2_xI + 5 , car2_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car2_xI + 25 , car2_yI + 5 , 5 , colors[BROWN]);
	glutPostRedisplay();
}

//============================================
// Name : drawcar_3
// Return : none
// Param : none
// Description : draws a car
//============================================

void drawcar_3()
{
	DrawSquare(car3_xI, car3_yI, 30, colors[DARK_CYAN]); // body of the car

	//tyres
	DrawCircle(car3_xI + 5 , car3_yI + 5 , 5 , colors[BROWN]);
	DrawCircle(car3_xI + 25 , car3_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car3_xI + 5 , car3_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car3_xI + 25 , car3_yI + 5 , 5 , colors[BROWN]);
	glutPostRedisplay();
}

//============================================
// Name : drawcar_4
// Return : none
// Param : none
// Description : draws a car
//============================================

void drawcar_4()
{
	DrawSquare(car4_xI, car4_yI, 30, colors[ORANGE]); // body of the car

	//tyres
	DrawCircle(car4_xI + 5 , car4_yI + 5 , 5 , colors[BROWN]);
	DrawCircle(car4_xI + 25 , car4_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car4_xI + 5 , car4_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car4_xI + 25 , car4_yI + 5 , 5 , colors[BROWN]);
	glutPostRedisplay();
}

//============================================
// Name : drawcar_5
// Return : none
// Param : none
// Description : draws a car
//============================================

void drawcar_5()
{
	DrawSquare(car5_xI, car5_yI, 30, colors[BLANCHED_ALMOND]); // body of the car

	//tyres
	DrawCircle(car5_xI + 5 , car5_yI + 5 , 5 , colors[BROWN]);
	DrawCircle(car5_xI + 25 , car5_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car5_xI + 5 , car5_yI + 25 , 5 , colors[BROWN]);
	DrawCircle(car5_xI + 25 , car5_yI + 5 , 5 , colors[BROWN]);
	glutPostRedisplay();
}

long int TIME; // This will store the time integer 

//================================================================================
// The function GetRandom() generates random numbers from 0 to 19 and returns it
//================================================================================

int GetRandom()
{
	int Time;
	Time = time(NULL); 
	TIME = TIME + Time; // A different value will be added everytime. This makes TIME different on every second
	srand(TIME); // Setting a different seed everytime to get a different random number
	int Rnumber;
	Rnumber = rand() % 19;
	return Rnumber;
}

//================================================================================
// The function GetRandom_1() generates random numbers from 0 to 4 and returns it
//================================================================================

int GetRandom_1()
{
	int Time;
	Time = time(NULL); 
	TIME = TIME + Time; // A different value will be added everytime. This makes TIME different on every second
	srand(TIME); // Setting a different seed everytime to get a different random number
	int Rnumber;
	Rnumber = rand() % 4;
	return Rnumber;
}

//================================================================================
// The function GetRandom_2() generates random numbers from 0 to 3 and returns it
//================================================================================

int GetRandom_2()
{
	int Time;
	Time = time(NULL); 
	TIME = TIME + Time; // A different value will be added everytime. This makes TIME different on every second
	srand(TIME); // Setting a different seed everytime to get a different random number
	int Rnumber;
	Rnumber = rand() % 3;
	return Rnumber;
}



// Initializing global variables to give random numbers so that the randomness is not overwritten everytime the output is refreshed
// We need the randomness to be in the 20x20 box. Implementing this with the help of randomly generated values of rows and column variables

// These will store the randomly generated column number
const int i_tree_1 = GetRandom();
const int i_tree_2 = GetRandom();
const int i_tree_3 = GetRandom();
const int i_tree_4 = GetRandom();
const int i_tree_5 = GetRandom();

// These will store the randomly generated row number
const int j_tree_1 = GetRandom();
const int j_tree_2 = GetRandom();
const int j_tree_3 = GetRandom();
const int j_tree_4 = GetRandom();
const int j_tree_5 = GetRandom();

// Initializing global variables to give random numbers so that the randomness is not overwritten everytime the output is refreshed
// We need the randomness to be in the 20x20 box. Implementing this with the help of randomly generated values of rows and column variables

// These will store the randomly generated column number
const int i_pass_1 = GetRandom();
const int i_pass_2 = GetRandom();
const int i_pass_3 = GetRandom();
const int i_pass_4 = GetRandom();
const int i_pass_5 = GetRandom();

// These will store the randomly generated row number
const int j_pass_1 = GetRandom();
const int j_pass_2 = GetRandom();
const int j_pass_3 = GetRandom();
const int j_pass_4 = GetRandom();
const int j_pass_5 = GetRandom();

// A constant number to check how many passengers do we want

const int N = GetRandom_1() ;

//==================================================
//
// Name : drawTree
// Return : none
// Param : none
// Description : Draw randomly placed trees on the 20x 20 board
//
//==================================================

void drawTree()
{
	// Drawing the trees 

	// The trees can be randomly placed in 20 columns
	
	// We need to draw 5 trees at random rows and random columns

	for(int i = 0 ; i <= 19 ; i++) // Columns
	{
		for (int j = 0 ; j <= 19 ; j++) // Rows
		{
			// Column for trees
			if (i == i_tree_1)
			{
				// Row for trees
				if(j == j_tree_1)
				{
					
					if(((rows[i_tree_1] != xI) || (cols[j_tree_1] != yI))) // Cannot be placed on the coordinates of the taxi
					{
						if ((((rows[i_tree_1] != x1[j][i] + 30)) && (cols[j_tree_1] != Y1[j][i])) && ((rows[i_tree_1] != tree_x1[i][j]) && (cols[j_tree_1] != tree_Y1[i][j]))) // The trees cannot be on the black track or on the passengers or on another tree or on any car
						{
							// Box containing the tree
							DrawSquare(rows[i_tree_1], cols[j_tree_1]  , 30 , colors[WHITE]);

							// Drawing 3 lines for the upper body of the tree and one wide line for the trunk of the tree
							DrawLine(rows[i_tree_1] , cols[j_tree_1] + 10 , rows[i_tree_1] + 30, cols[j_tree_1] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_1] , cols[j_tree_1] + 10 , rows[i_tree_1] + 15, cols[j_tree_1] + 30 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_1] + 15 , cols[j_tree_1] + 30 , rows[i_tree_1] + 30, cols[j_tree_1] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_1] + 15 , cols[j_tree_1] , rows[i_tree_1] + 15, cols[j_tree_1] + 10 , 5 , colors[BROWN]);

							// Store the dimensions of the tree in arrays
							tree_x1[j][i] = rows[i] - 30;
							tree_x2[j][i] = rows[i];

							tree_Y1[j][i] = cols[j];
							tree_y2[j][i] = cols[j] + 30;
							
						}



					}
					
				}
			}

			// Column for trees
			if (i == i_tree_2)
			{
				// Row for trees
				if(j == j_tree_2)
				{

					if(((rows[i_tree_2] != xI) || (cols[j_tree_2] != yI))) // Cannot be placed on the coordinates of the taxi
					{
						if ((((rows[i_tree_2] != x1[j][i] + 30)) && (cols[j_tree_2] != Y1[j][i])) && ((rows[i_tree_2] != tree_x1[i][j]) && (cols[j_tree_2] != tree_Y1[i][j]))) // The trees cannot be on the black track or on the passengers or on another tree or on any car
						{
							// Box containing the tree
							DrawSquare(rows[i_tree_2], cols[j_tree_2]  , 30 , colors[WHITE]);

							// Drawing 3 lines for the upper body of the tree and one wide line for the trunk of the tree
							DrawLine(rows[i_tree_2] , cols[j_tree_2] + 10 , rows[i_tree_2] + 30, cols[j_tree_2] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_2] , cols[j_tree_2] + 10 , rows[i_tree_2] + 15, cols[j_tree_2] + 30 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_2] + 15 , cols[j_tree_2] + 30 , rows[i_tree_2] + 30, cols[j_tree_2] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_2] + 15 , cols[j_tree_2] , rows[i_tree_2] + 15, cols[j_tree_2] + 10 , 5 , colors[BROWN]);


							// Store the dimensions of the tree in arrays
							tree_x1[j][i] = rows[i] - 30;
							tree_x2[j][i] = rows[i];

							tree_Y1[j][i] = cols[j];
							tree_y2[j][i] = cols[j] + 30;
						}

					}
				}


			}

			// Column for trees
			if (i == i_tree_3)
			{
				// Row for trees
				if(j == j_tree_3)
				{

					if(((rows[i_tree_3] != xI) || (cols[j_tree_3] != yI))) // Cannot be placed on the coordinates of the taxi
					{
						if ((((rows[i_tree_3] != x1[j][i] + 30)) && (cols[j_tree_3] != Y1[j][i])) && ((rows[i_tree_3] != tree_x1[i][j]) && (cols[j_tree_3] != tree_Y1[i][j]))) // The trees cannot be on the black track or on the passengers or on another tree or on any car
						{
							// Box containing the tree
							DrawSquare(rows[i_tree_3], cols[j_tree_3]  , 30 , colors[WHITE]);

							// Drawing 3 lines for the upper body of the tree and one wide line for the trunk of the tree
							DrawLine(rows[i_tree_3] , cols[j_tree_3] + 10 , rows[i_tree_3] + 30, cols[j_tree_3] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_3] , cols[j_tree_3] + 10 , rows[i_tree_3] + 15, cols[j_tree_3] + 30 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_3] + 15 , cols[j_tree_3] + 30 , rows[i_tree_3] + 30, cols[j_tree_3] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_3] + 15 , cols[j_tree_3] , rows[i_tree_3] + 15, cols[j_tree_3] + 10 , 5 , colors[BROWN]);


							// Store the dimensions of the tree in arrays
							tree_x1[j][i] = rows[i] - 30;
							tree_x2[j][i] = rows[i];

							tree_Y1[j][i] = cols[j];
							tree_y2[j][i] = cols[j] + 30;
						}

					}

				}

				

			}	

			// Column for trees
			if (i == i_tree_4)
			{
				// Row for trees
				if(j == j_tree_4)
				{

					if(((rows[i_tree_4] != xI) || (cols[j_tree_4] != yI))) // Cannot be placed on the coordinates of the taxi
					{
						if ((((rows[i_tree_4] != x1[j][i] + 30)) && (cols[j_tree_4] != Y1[j][i])) && ((rows[i_tree_4] != tree_x1[i][j]) && (cols[j_tree_4] != tree_Y1[i][j]))) // The trees cannot be on the black track or on the passengers or on another tree or on any car
						{
							// Box containing the tree
							DrawSquare(rows[i_tree_4], cols[j_tree_4]  , 30 , colors[WHITE]);

							// Drawing 3 lines for the upper body of the tree and one wide line for the trunk of the tree
							DrawLine(rows[i_tree_4] , cols[j_tree_4] + 10 , rows[i_tree_4] + 30, cols[j_tree_4] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_4] , cols[j_tree_4] + 10 , rows[i_tree_4] + 15, cols[j_tree_4] + 30 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_4] + 15 , cols[j_tree_4] + 30 , rows[i_tree_4] + 30, cols[j_tree_4] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_4] + 15 , cols[j_tree_4] , rows[i_tree_4] + 15, cols[j_tree_4] + 10 , 5 , colors[BROWN]);


							// Store the dimensions of the tree in arrays
							tree_x1[j][i] = rows[i] - 30;
							tree_x2[j][i] = rows[i];

							tree_Y1[j][i] = cols[j];
							tree_y2[j][i] = cols[j] + 30;
						}

					}

				}

			}

			// Column for trees
			if (i == i_tree_5)
			{
				// Row for trees
				if(j == j_tree_5)
				{

					if(((rows[i_tree_5] != xI) || (cols[j_tree_5] != yI))) // Cannot be placed on the coordinates of the taxi
					{
						if ((((rows[i_tree_5] != x1[j][i] + 30)) && (cols[j_tree_5] != Y1[j][i])) && ((rows[i_tree_5] != tree_x1[i][j]) && (cols[j_tree_5] != tree_Y1[i][j]))) // The trees cannot be on the black track or on the passengers or on another tree or on any car
						{
							// Box containing the tree
							DrawSquare(rows[i_tree_5], cols[j_tree_5]  , 30 , colors[WHITE]);

							// Drawing 3 lines for the upper body of the tree and one wide line for the trunk of the tree
							DrawLine(rows[i_tree_5] , cols[j_tree_5] + 10 , rows[i_tree_5] + 30, cols[j_tree_5] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_5] , cols[j_tree_5] + 10 , rows[i_tree_5] + 15, cols[j_tree_5] + 30 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_5] + 15 , cols[j_tree_5] + 30 , rows[i_tree_5] + 30, cols[j_tree_5] + 10 , 3 , colors[GREEN]);
							DrawLine(rows[i_tree_5] + 15 , cols[j_tree_5] , rows[i_tree_5] + 15, cols[j_tree_5] + 10 , 5 , colors[BROWN]);


							// Store the dimensions of the tree in arrays
							tree_x1[j][i] = rows[i] - 30;
							tree_x2[j][i] = rows[i];

							tree_Y1[j][i] = cols[j];
							tree_y2[j][i] = cols[j] + 30;
						}

					}

				}

			}		
		}
	
	}
	
	glutPostRedisplay();
}

// Flags for passengers' picking up

bool pass_flag_1[20][20];
/* bool pass_flag_2[20][20];
bool pass_flag_3[20][20];
bool pass_flag_4[20][20];
bool pass_flag_5[20][20]; */



//===================================================
// Name : InitPassFlag
// Return : none
// Param : none
// Description : Initializes the passenger flags to true
//===================================================

void InitPassFlag()
{
	// Initializing the passenger flags to true

	for(int i = 0 ; (i <= 19) ; i++)
	{
		for(int j = 0 ; (j <= 19) ; j++)
	 	{
			pass_flag_1[j][i] = true;
		}
	}
}

//==================================================
//
// Name : drawPass
// Return : none
// Param : none
// Description : Draw randomly placed passengers on the 20x 20 board
//
//==================================================

const int i_dest= GetRandom();
const int j_dest = GetRandom();

void drawPass()
{


	if (N == 0)
	{
		// Drawing the passengers 

		// The passengers can be randomly placed in 20x20 box

		for(int i = 0 ; i <= 19 ; i++) // Columns
		{
			for (int j = 0 ; j <= 19 ; j++) // Rows
			{
				// Column for passenger
				if (i == i_pass_1)
				{
					// Row for passenger
					if(j == j_pass_1)
					{
						
						if(((rows[i_pass_1] != xI) || (cols[j_pass_1] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_1], cols[j_pass_1]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_1] + 15 , cols[j_pass_1] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 20 , rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] , cols[j_pass_1] + 10 , rows[i_pass_1] + 30 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 5 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 25 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);
								
							}

							// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}

						}
						
					}
				}

			}		
		}
	}

	// If there are two passengers
	if (N == 1)
	{
		// Drawing the passengers 

		// The passengers can be randomly placed in 20x20 box

		for(int i = 0 ; i <= 19 ; i++) // Columns
		{
			for (int j = 0 ; j <= 19 ; j++) // Rows
			{
				// Column for passenger
				if (i == i_pass_1)
				{
					// Row for passenger
					if(j == j_pass_1)
					{
						
						if(((rows[i_pass_1] != xI) || (cols[j_pass_1] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j]) && ((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_1], cols[j_pass_1]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_1] + 15 , cols[j_pass_1] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 20 , rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] , cols[j_pass_1] + 10 , rows[i_pass_1] + 30 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 5 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 25 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

				// Column for passenger
				if (i == i_pass_2)
				{
					// Row for passenger
					if(j == j_pass_2)
					{
						
						if(((rows[i_pass_2] != xI) || (cols[j_pass_2] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_2] != x1[j][i] + 30)) && (cols[j_pass_2] != Y1[j][i])) && ((rows[i_pass_2] != tree_x1[i][j]) && (cols[j_pass_2] != tree_Y1[i][j]) && ((rows[i_pass_2] != pass_x1[i][j]) && (cols[j_pass_2] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_2], cols[j_pass_2]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_2] + 15 , cols[j_pass_2] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 20 , rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] , cols[j_pass_2] + 10 , rows[i_pass_2] + 30 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 5 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 25 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);

								/// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

			}		
		}
	}
	
	// If there are three passengers
	if (N == 2)
	{
		// Drawing the passengers 

		// The passengers can be randomly placed in 20x20 box

		for(int i = 0 ; i <= 19 ; i++) // Columns
		{
			for (int j = 0 ; j <= 19 ; j++) // Rows
			{
				// Column for passenger
				if (i == i_pass_1)
				{
					// Row for passenger
					if(j == j_pass_1)
					{
						
						if(((rows[i_pass_1] != xI) || (cols[j_pass_1] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j]) && ((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_1], cols[j_pass_1]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_1] + 15 , cols[j_pass_1] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 20 , rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] , cols[j_pass_1] + 10 , rows[i_pass_1] + 30 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 5 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 25 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}
				
				// Column for passenger
				if (i == i_pass_2)
				{
					// Row for passenger
					if(j == j_pass_2)
					{
						
						if(((rows[i_pass_2] != xI) || (cols[j_pass_2] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_2] != x1[j][i] + 30)) && (cols[j_pass_2] != Y1[j][i])) && ((rows[i_pass_2] != tree_x1[i][j]) && (cols[j_pass_2] != tree_Y1[i][j]) && ((rows[i_pass_2] != pass_x1[i][j]) && (cols[j_pass_2] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_2], cols[j_pass_2]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_2] + 15 , cols[j_pass_2] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 20 , rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] , cols[j_pass_2] + 10 , rows[i_pass_2] + 30 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 5 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 25 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);

								/// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

				// Column for passenger
				if (i == i_pass_3)
				{
					// Row for passenger
					if(j == j_pass_3)
					{
						
						if(((rows[i_pass_3] != xI) || (cols[j_pass_3] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_3] != x1[j][i] + 30)) && (cols[j_pass_3] != Y1[j][i])) && ((rows[i_pass_3] != tree_x1[i][j]) && (cols[j_pass_3] != tree_Y1[i][j]) && ((rows[i_pass_3] != pass_x1[i][j]) && (cols[j_pass_3] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_3], cols[j_pass_3]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_3] + 15 , cols[j_pass_3] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 20 , rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] , cols[j_pass_3] + 10 , rows[i_pass_3] + 30 , cols[j_pass_3] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , rows[i_pass_3] + 5 , cols[j_pass_3] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , rows[i_pass_3] + 25 , cols[j_pass_3] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

			}		
		}
	}

	// If there are four passengers
	if (N == 3)
	{
		// Drawing the passengers 

		// The passengers can be randomly placed in 20x20 box

		for(int i = 0 ; i <= 19 ; i++) // Columns
		{
			for (int j = 0 ; j <= 19 ; j++) // Rows
			{
				// Column for passenger
				if (i == i_pass_4)
				{
					// Row for passenger
					if(j == j_pass_4)
					{
						
						if(((rows[i_pass_4] != xI) || (cols[j_pass_4] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_4] != x1[j][i] + 30)) && (cols[j_pass_4] != Y1[j][i])) && ((rows[i_pass_4] != tree_x1[i][j]) && (cols[j_pass_4] != tree_Y1[i][j]) && ((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_4], cols[j_pass_4]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_4] + 15 , cols[j_pass_4] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_4] + 15 , cols[j_pass_4] + 20 , rows[i_pass_4] + 15 , cols[j_pass_4] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_4] , cols[j_pass_4] + 10 , rows[i_pass_4] + 30 , cols[j_pass_4] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_4] + 15 , cols[j_pass_4] + 10 , rows[i_pass_4] + 5 , cols[j_pass_4] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_4] + 15 , cols[j_pass_4] + 10 , rows[i_pass_4] + 25 , cols[j_pass_4] , 2 , colors[CHOCOLATE]);

								/// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}
				
				// Column for passenger
				if (i == i_pass_2)
				{
					// Row for passenger
					if(j == j_pass_2)
					{
						
						if(((rows[i_pass_2] != xI) || (cols[j_pass_2] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_2] != x1[j][i] + 30)) && (cols[j_pass_2] != Y1[j][i])) && ((rows[i_pass_2] != tree_x1[i][j]) && (cols[j_pass_2] != tree_Y1[i][j]) && ((rows[i_pass_2] != pass_x1[i][j]) && (cols[j_pass_2] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_2], cols[j_pass_2]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_2] + 15 , cols[j_pass_2] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 20 , rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] , cols[j_pass_2] + 10 , rows[i_pass_2] + 30 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 5 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 25 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);

								//// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

				// Column for passenger
				if (i == i_pass_3)
				{
					// Row for passenger
					if(j == j_pass_3)
					{
						
						if(((rows[i_pass_3] != xI) || (cols[j_pass_3] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_3] != x1[j][i] + 30)) && (cols[j_pass_3] != Y1[j][i])) && ((rows[i_pass_3] != tree_x1[i][j]) && (cols[j_pass_3] != tree_Y1[i][j]) && ((rows[i_pass_3] != pass_x1[i][j]) && (cols[j_pass_3] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_3], cols[j_pass_3]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_3] + 15 , cols[j_pass_3] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 20 , rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] , cols[j_pass_3] + 10 , rows[i_pass_3] + 30 , cols[j_pass_3] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , rows[i_pass_3] + 5 , cols[j_pass_3] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , rows[i_pass_3] + 25 , cols[j_pass_3] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

				// Column for passenger
				if (i == i_pass_1)
				{
					// Row for passenger
					if(j == j_pass_1)
					{
						
						if(((rows[i_pass_1] != xI) || (cols[j_pass_1] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (pass_flag_1[i][j] == true)) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_1], cols[j_pass_1]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_1] + 15 , cols[j_pass_1] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 20 , rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] , cols[j_pass_1] + 10 , rows[i_pass_1] + 30 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 5 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 25 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

			}		
		}
	}

	// If there are five passengers
	if (N == 4)
	{
		// Drawing the passengers 

		// The passengers can be randomly placed in 20x20 box

		for(int i = 0 ; i <= 19 ; i++) // Columns
		{
			for (int j = 0 ; j <= 19 ; j++) // Rows
			{
				// Column for passenger
				if (i == i_pass_5)
				{
					// Row for passenger
					if(j == j_pass_5)
					{
						
						if(((rows[i_pass_5] != xI) || (cols[j_pass_5] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_5] != x1[j][i] + 30)) && (cols[j_pass_5] != Y1[j][i])) && ((rows[i_pass_5] != tree_x1[i][j]) && (cols[j_pass_5] != tree_Y1[i][j]) && ((rows[i_pass_5] != pass_x1[i][j]) && (cols[j_pass_5] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_5], cols[j_pass_5]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_5] + 15 , cols[j_pass_5] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_5] + 15 , cols[j_pass_5] + 20 , rows[i_pass_5] + 15 , cols[j_pass_5] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_5] , cols[j_pass_5] + 10 , rows[i_pass_5] + 30 , cols[j_pass_5] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_5] + 15 , cols[j_pass_5] + 10 , rows[i_pass_5] + 5 , cols[j_pass_5] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_5] + 15 , cols[j_pass_5] + 10 , rows[i_pass_5] + 25 , cols[j_pass_5] , 2 , colors[CHOCOLATE]);

								/// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}


				// Column for passenger
				if (i == i_pass_4)
				{
					// Row for passenger
					if(j == j_pass_4)
					{
						
						if(((rows[i_pass_4] != xI) || (cols[j_pass_4] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_4] != x1[j][i] + 30)) && (cols[j_pass_4] != Y1[j][i])) && ((rows[i_pass_4] != tree_x1[i][j]) && (cols[j_pass_4] != tree_Y1[i][j]) && ((rows[i_pass_4] != pass_x1[i][j]) && (cols[j_pass_4] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_4], cols[j_pass_4]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_4] + 15 , cols[j_pass_4] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_4] + 15 , cols[j_pass_4] + 20 , rows[i_pass_4] + 15 , cols[j_pass_4] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_4] , cols[j_pass_4] + 10 , rows[i_pass_4] + 30 , cols[j_pass_4] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_4] + 15 , cols[j_pass_4] + 10 , rows[i_pass_4] + 5 , cols[j_pass_4] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_4] + 15 , cols[j_pass_4] + 10 , rows[i_pass_4] + 25 , cols[j_pass_4] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
							}

						}
						
					}
				}
				
				// Column for passenger
				if (i == i_pass_2)
				{
					// Row for passenger
					if(j == j_pass_2)
					{
						
						if(((rows[i_pass_2] != xI) || (cols[j_pass_2] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_2] != x1[j][i] + 30)) && (cols[j_pass_2] != Y1[j][i])) && ((rows[i_pass_2] != tree_x1[i][j]) && (cols[j_pass_2] != tree_Y1[i][j]) && ((rows[i_pass_2] != pass_x1[i][j]) && (cols[j_pass_2] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_2], cols[j_pass_2]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_2] + 15 , cols[j_pass_2] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 20 , rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] , cols[j_pass_2] + 10 , rows[i_pass_2] + 30 , cols[j_pass_2] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 5 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_2] + 15 , cols[j_pass_2] + 10 , rows[i_pass_2] + 25 , cols[j_pass_2] , 2 , colors[CHOCOLATE]);

								/// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

				// Column for passenger
				if (i == i_pass_3)
				{
					// Row for passenger
					if(j == j_pass_3)
					{
						
						if(((rows[i_pass_3] != xI) || (cols[j_pass_3] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_3] != x1[j][i] + 30)) && (cols[j_pass_3] != Y1[j][i])) && ((rows[i_pass_3] != tree_x1[i][j]) && (cols[j_pass_3] != tree_Y1[i][j]) && ((rows[i_pass_3] != pass_x1[i][j]) && (cols[j_pass_3] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_3], cols[j_pass_3]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_3] + 15 , cols[j_pass_3] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 20 , rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] , cols[j_pass_3] + 10 , rows[i_pass_3] + 30 , cols[j_pass_3] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , rows[i_pass_3] + 5 , cols[j_pass_3] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_3] + 15 , cols[j_pass_3] + 10 , rows[i_pass_3] + 25 , cols[j_pass_3] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

				// Column for passenger
				if (i == i_pass_1)
				{
					// Row for passenger
					if(j == j_pass_1)
					{
						
						if(((rows[i_pass_1] != xI) || (cols[j_pass_1] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j]) && ((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && ((pass_flag_1[i][j] == true)))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i_pass_1], cols[j_pass_1]  , 30 , colors[WHITE]);

								// Head of the passenger
								DrawCircle(rows[i_pass_1] + 15 , cols[j_pass_1] + 25 , 5 , colors[DIM_GRAY]);

								// Body of the passenger
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 20 , rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] , cols[j_pass_1] + 10 , rows[i_pass_1] + 30 , cols[j_pass_1] + 10 , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 5 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);
								DrawLine(rows[i_pass_1] + 15 , cols[j_pass_1] + 10 , rows[i_pass_1] + 25 , cols[j_pass_1] , 2 , colors[CHOCOLATE]);

								// Store the dimensions of the tree in arrays

							if ((pass_flag_1[i][j] == true))
							{
								if ((((rows[i_pass_1] != x1[j][i] + 30)) && (cols[j_pass_1] != Y1[j][i])) && ((rows[i_pass_1] != tree_x1[i][j]) && (cols[j_pass_1] != tree_Y1[i][j])) && (((rows[i_pass_1] != pass_x1[i][j]) && (cols[j_pass_1] != pass_Y1[i][j])) && (pass_flag_1[i][j] == true))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
								{
									pass_x1[j][i] = rows[i] - 30;
									pass_x2[j][i] = rows[i];

									pass_Y1[j][i] = cols[j];
									pass_y2[j][i] = cols[j] + 30;
								}
							}

							else
								{
									pass_x1[j][i] = 0;
									pass_x2[j][i] = 0;

									pass_Y1[j][i] = 0;
									pass_y2[j][i] = 0;
								}
								
							}

						}
						
					}
				}

			}		
		}
	}

	glutPostRedisplay(); 
}

void drawDestination()
{
	/* cout << "randomizer[1] : " << randomizer[1] << endl;
	cout << "randomizer[2] : " << randomizer[2] << endl; */

	/* for(int i = 0 ; i <= 19 ; i++)
	{
		const int randomizer[i] = {GetRandom()};
	} */

	// The destination can be randomly placed in 20x20 box

		for(int i = 0 ; i <= 19 ; i++) // Columns
		{
			for (int j = 0 ; j <= 19 ; j++) // Rows
			{
				// Column for passenger
				if (i == i_dest)
				{
					// Row for passenger
					if(j == j_dest)
					{
						
						if(((rows[i] != xI) || (cols[j] != yI))) // Cannot be placed on the coordinates of the taxi
						{
							if ((((rows[i] != x1[j][i] + 30)) && (cols[j] != Y1[j][i])) && ((rows[i] != tree_x1[i][j]) && (cols[j] != tree_Y1[i][j])) && (((rows[i] != pass_x1[i][j]) && (cols[j] != pass_Y1[i][j])))) // The passengers cannot be on the black track or on the passengers or on another tree or on any car
							{
								// Box containing the tree
								DrawSquare(rows[i], cols[j]  , 30 , colors[GREEN]);
							}
						}
	
					}
				}
			}
		}
}

// Starting directions for 5 cars

const int direction_1 = GetRandom_2();
const int direction_2 = GetRandom_2();
const int direction_3 = GetRandom_2();
const int direction_4 = GetRandom_2();
const int direction_5 = GetRandom_2();

// Flags for cars

bool flag_1 = true;
bool flag_2 = true;
bool flag_3 = true;
bool flag_4 = true;


//====================================
// Name : moveCar
// Param : none
// Return : none
// Description: moves cars in different directions
//====================================

void moveCar()
{
	// Move the car in left direction

	if(direction_1 == 0)
	{
		cout << direction_1 << endl;
		// the car is not allowed to go out of the left line of the box
		if(!((car1_xI - 2.5) < 180) && (flag_1 == true)) 
		{
			car1_xI -= 2.5;
			if(((car1_xI - 2.5) < 180))
			{
				flag_1 = false;
			}
		}

		else if (flag_1 == false)
		{
			car1_xI += 2.5;

			if((car1_xI + 2.5) > 780)
			{
				flag_1 = true;
			}
		}
	}
	
	if(direction_1 == 1)
	{
		cout << direction_1 << endl;
		// the car is not allowed to go out of the top line of the box
		if(((car1_yI + 2.5) <= 612.5 && (flag_1 == true))) 
		{
			car1_yI += 2.5;

			if (!((car1_yI + 2.5) < 612.5))
			{
				flag_1 = false;
			}
			
		}

		if (flag_1 == false)
		{
			car1_yI -= 2.5;

			if(!((car1_yI - 2.5) > 40))
			{
				flag_1 = true;
			}
			
		}
	}

	if(direction_1 == 2)
	{
		cout << direction_1 << endl;
		// the car is not allowed to go out of the down line of the box
		if((((car1_yI - 2.5) > 40)) && (flag_1 == true)) 
		{
			car1_yI -= 2.5;

			if (!((car1_yI - 2.5) > 40))
			{
				flag_1 = false;
			}
			
		}

		if (flag_1 == false)
		{
			car1_yI += 2.5;

			if ((car1_yI + 2.5) > 610)
			{
				flag_1 = true;
			}
		}
	}

	if(direction_1 == 3)
	{
		cout << direction_1 << endl;
		// the car is not allowed to go out of the right line of the box
		if((((car1_xI + 2.5) > 780)) && (flag_1 == true)) 
		{
			car1_xI += 2.5;

			if (!((car1_xI - 2.5) > 780))
			{
				flag_1 = false;
			}
			
		}

		if (flag_1 == false)
		{
			if((car1_xI - 2.5) < 180)
			{
				flag_1 = true;
			}
			car1_xI -= 2.5;
		}
	}
	

	


	
	/* if (car1_xI > 10 && flag) {
		car1_xI -= 10;
		cout << "going left";
		if(xI < 100)
			
			flag = false;

	}
	else if (car1_xI < 1010 && !flag) {
		cout << "go right";
		car1_xI += 10;
		if (xI > 900)
			flag = true;
	} */
}

/*
 * Main Canvas drawing function.
 * */

/* unsigned */ int score = 0;

void GameDisplay()/**/{
	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

	glClearColor(1/*Red Component*/, 1,	//148.0/255/*Green Component*/,
			1/*Blue Component*/, 1 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	//Red Square
	//DrawSquare(400, 20, 40, colors[RED]);
	
	//Green Square
	//DrawSquare( 250 , 250 ,20,colors[GREEN]); 
	
	//Display Score
	DrawString( 50, 800, "Score : ", colors[MAROON]);
	DrawString( 120, 800, to_string(score) , colors[MAROON]);
	
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
	//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] ); 
	


	/// building a box of 600 x 600 pixels which will be divided into 20 x 20 squares
	//DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)

	DrawLine( 180 , 40  , 780 , 40 , 1 , colors[BLUE_VIOLET]); // bottom line
	DrawLine( 180 , 640  , 780 , 640 , 1 , colors[BLUE_VIOLET]); // top line
	DrawLine( 180 , 40  , 180 , 640 , 1 , colors[BLUE_VIOLET]); // left line	
	DrawLine( 780 , 40  , 780 , 640 , 1 , colors[BLUE_VIOLET]); // right line

	// Dividing the rows and columns of the 20x20 box into small equal boxes of 30x30 dimensions

	int n = 180 , m = 610; //n and m represent the x and y dimensions 

	for(int i = 0 ; i <= 19 ; i++)
	{
		rows[i] = n; // this array contains all the x-components where a small 30x30 box can be placed according to the bigger box
		n = n + 30;
	}

	 
	for(int i = 0 ; i <= 19 ; i++)
	{
		cols[i] = m; // this array contains all the y-components where a small 30x30 box can be placed according to the bigger box
		m = m - 30;
	}

	// Drawing the black track (cars cannot go here)

	for(int i = 0 ; i <= 19 ; i++) // Columns
	{
		for(int j = 0 ; j <= 19 ; j++) // Rows
		{
			// Column 3
			if (i == 2)
			{
				// Row 6
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row seven
				if (j == 6)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row eight
				if (j == 7)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 13
				if (j == 12)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 14
				if (j == 13)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 15
				if (j == 14)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				
			}

			// Column 4
			if(i == 3)
			{
				// Row 6
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 15
				if (j == 14)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}


			}

			// Column 5
			if(i == 4)
			{
				// Row 6
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 15
				if (j == 14)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 16
				if (j == 15)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 17
				if (j == 16)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}


			}

			// Column 8
			if(i == 7)
			{
				// Row 3
				if (j == 2)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 11
				if (j == 10)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 18
				if (j == 17)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 9
			if(i == 8)
			{
				// Row 3
				if (j == 2)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 11
				if (j == 10)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 18
				if (j == 17)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 10
			if(i == 9)
			{
				// Row 3
				if (j == 2)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 11
				if (j == 10)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 18
				if (j == 17)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 19
				if (j == 18)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 11
			if(i == 10)
			{
				// Row 2
				if (j == 1)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 3
				if (j == 2)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 4
				if (j == 3)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 14
				if (j == 13)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 15
				if (j == 14)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

			}

			// Column 14
			if(i == 13)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 6
				if (j == 6)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 15
			if(i == 14)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 16
			if(i == 15)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 13
				if (j == 12)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 17
			if(i == 16)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 13
				if (j == 12)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 18
			if(i == 17)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 13
				if (j == 12)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}
			
			// Column 19
			if(i == 18)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 13
				if (j == 12)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}
			}

			// Column 20
			if(i == 19)
			{
				// Row 5
				if (j == 5)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				


				// Row 20
				if (j == 19)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 10
				if (j == 9)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 11
				if (j == 10)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 12
				if (j == 11)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 13
				if (j == 12)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 14
				if (j == 13)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 15
				if (j == 14)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 15
				if (j == 14)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				// Row 16
				if (j == 15)
				{
					DrawSquare(rows[i] , cols[j] , 30 , colors[BLACK]);

					// Store the dimensions of the box in arrays
					x1[j][i] = rows[i] - 30;
					x2[j][i] = rows[i];

					Y1[j][i] = cols[j];
					y2[j][i] = cols[j] + 30;
				}

				
			}

		}
	}

	
	
	/* DrawCircle(50,670,10,colors[RED]);
	DrawCircle(70,670,10,colors[RED]);
	DrawCircle(90,670,10,colors[RED]);
	DrawRoundRect(500,200,50,100,colors[DARK_SEA_GREEN],70);
	DrawRoundRect(100,200,100,50,colors[DARK_OLIVE_GREEN],20);	
	DrawRoundRect(100,100,50,100,colors[DARK_OLIVE_GREEN],30);
	DrawRoundRect(200,100,100,50,colors[LIME_GREEN],40);
	DrawRoundRect(350,100,100,50,colors[LIME_GREEN],20); */
	
	drawTaxi();
	drawTree();
	drawPass();
	drawcar_1();
	drawcar_2();
	drawcar_3();
	drawcar_4();
	drawcar_5();

	glutPostRedisplay();
	glutSwapBuffers(); // do not modify this line..

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */



// Variable to know the iteration

unsigned int I;
unsigned int J;

// Flags for passenger pick up

bool flag_7 = false;
bool flag_8 = true;

bool flag_9 = false;
bool flag_10 = true;

bool flag_11 = false;
bool flag_12 = true;

bool flag_13 = false;
bool flag_14 = true;
void PrintableKeys(unsigned char key, int x, int y) {

	flag_7 = false;
	flag_8 = true;

	flag_9 = false;
	flag_10 = true;

	flag_11 = false;
	flag_12 = true;

	flag_13 = false;
	flag_14 = true;

	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	// Condition for picking up the passenger

	// When the left key is pressed 

	// comparing the dimensions of the car with each passenger

	// When the car is on the right 

			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if(((yI + 30) > pass_Y1[i][j]) && (yI < pass_y2[i][j])) // If the car is within the y-coordinate range
					{
						if(((xI - 35) < pass_x1[i][j]) || ((xI - 35) > pass_x2[i][j]) && ((xI + 5 < pass_x1[i][j]) || (xI + 5 > pass_x2[i][j]))) // If the car is not next to the passenger
						{
							flag_7 = true;
						}
						else // If the car is next to the passenger
						{
							flag_7 = false;
							flag_8 = false;

							// store the dimensions on which the flag was false
							I = i;
							J = j; 

							break;
						}
					}
					else
					{
						flag_7 = true;
					}
				}

				if(flag_8 == false)
				{
					break;
				}

				
			}

			// When the car is on the left

			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if(((yI + 30) > pass_Y1[i][j]) && (yI < pass_y2[i][j])) // If the car is within the y-coordinate range
					{
						if(((xI + 5 < pass_x1[i][j]) || (xI + 5 > pass_x2[i][j]))) // If the car is not next to the passenger
						{
							flag_9 = true;
						}
						else // If the car is next to the passenger
						{
							flag_9 = false;
							flag_10 = false;

							// store the dimensions on which the flag was false
							I = i;
							J = j; 

							break;
						}
					}
					else
					{
						flag_9 = true;
					}
				}

				if(flag_10 == false)
				{
					break;
				}

				
			}

			// When the car is on the top

			// comparing the dimensions of the car with each small box of the passenger
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if((xI > pass_x1[i][j]) && ((xI - 30) < pass_x2[i][j])) // If the car is within the x-coordinate range
					{
						
						if((yI - 5 < pass_Y1[i][j]) || (yI - 5 > pass_y2[i][j])) // Move the car if it is on the top of a tree OR on the bottom 
						{
							
							flag_11 = true;
						}
						else
						{
							flag_11 = false;
							flag_12 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_11 = true;
					}
				}

				if(flag_12 == false)
				{
					break;
				}

				
			}

			// When the car is on the bottom

			// comparing the dimensions of the car with each small box of the passenger
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if((xI > pass_x1[i][j]) && ((xI - 30) < pass_x2[i][j])) // If the car is within the x-coordinate range
					{
						if(((yI + 35) < pass_Y1[i][j]) || ((yI + 35) > pass_y2[i][j])) // Move the car if it is on the top of a tree OR on the bottom 
						{
							
							flag_13 = true;
						}
						else
						{
							flag_13 = false;
							flag_14 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_13 = true;
					}
				}

				if(flag_14 == false)
				{
					break;
				}
				
			}





	
	// If the car is in the vacinity of picking up a passenger
		if((flag_7 == false) && (key == 32))
		{
			pass_flag_1[J][I] = false;
			drawDestination();
		}

	// If the car is in the vacinity of picking up a passenger
	if((flag_9 == false) && (key == 32))
	{
		pass_flag_1[J][I] = false;
		drawDestination();
	}

	// If the car is in the vacinity of picking up a passenger
	if((flag_11 == false) && (key == 32))
	{
		pass_flag_1[J][I] = false;
		drawDestination();
	}

	// If the car is in the vacinity of picking up a passenger
	if((flag_13 == false) && (key == 32))
	{
		pass_flag_1[J][I] = false;
		drawDestination();
	}


	glutPostRedisplay();
}


/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */



void NonPrintableKeys(int key, int x, int y)
{

	// Flags for black track collision
	bool flag_1;
	bool flag_2;

	// Flags for object collision
	bool flag_3;
	bool flag_4;

	// Flags for passenger detection
	bool flag_5;
	bool flag_6;

	if (key == GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/)
	{
		flag_1 = false;
		flag_2 = true;

		flag_3 = false;
		flag_4 = true;

		flag_5 = false;
		flag_6 = true;

		// what to do when left key is pressed...
		if(!((xI - 5) < 180)) // the car is not allowed to go out of the left line of the box
		{
			// comparing the dimensions of the car with each small box of the black track
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if(((yI + 30) > Y1[i][j]) && (yI < y2[i][j])) // If the car is within the y-coordinate range
					{
						if(((xI - 30) < x1[i][j]) || ((xI - 30) > x2[i][j])) // Move the car if it is on the left of a black box OR on the right 
						{
							flag_1 = true;
						}
						else
						{
							flag_1 = false;
							flag_2 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_1 = true;
					}
				}

				if(flag_2 == false)
				{
					break;
				}

				
			}


			// comparing the dimensions of the car with each small box of the tree
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if(((yI + 30) > tree_Y1[i][j]) && (yI < tree_y2[i][j])) // If the car is within the y-coordinate range
					{
						if(((xI - 30) < tree_x1[i][j]) || ((xI - 30) > tree_x2[i][j])) // Move the car if it is on the left of a tree OR on the right 
						{
							flag_3 = true;
						}
						else
						{
							flag_3 = false;
							flag_4 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_3 = true;
					}
				}

				if(flag_4 == false)
				{
					break;
				}

				
			}


			// comparing the dimensions of the car with each passenger
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if(((yI + 30) > pass_Y1[i][j]) && (yI < pass_y2[i][j])) // If the car is within the y-coordinate range
					{
						if(((xI - 30) < pass_x1[i][j]) || ((xI - 30) > pass_x2[i][j])) // Move the car if it is on the left of a passenger OR on the right 
						{
							flag_5 = true;
						}
						else
						{
							flag_5 = false;
							flag_6 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_5 = true;
					}
				}

				if(flag_6 == false)
				{
					break;
				}

				
			}

			

			
		}

		else if((xI - 5) < 180)
		{
			flag_3 = true;
			flag_5 = true;
		}
		
		// If the moving condition is satisfied then move the car
		if ((flag_1 == true) && (flag_3 == true) && (flag_5 == true))
		{
			xI -= 5;
			cout << xI << endl;
		}

		// If the car hits an obstacle

		if (flag_3 == false)
		{
			score = score - 4;
		}

		// If the car hits a passenger

		if (flag_5 == false)
		{
			score = score - 5;
		}

		
	}


	else if (key == GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/)
	{
		flag_1 = false;
		flag_2 = true;

		flag_3 = false;
		flag_4 = true;

		flag_5 = false;
		flag_6 = true;

		if (!((xI + 5) > 750)) // the car cannot go outside the 20x20 box
		{
			// comparing the dimensions of the car with each small box of the black track
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if(((yI + 30) > Y1[i][j]) && (yI < y2[i][j])) // If the car is within the y-coordinate range
					{

						if((xI < x1[i][j]) || (xI > x2[i][j])) // Move the car if it is on the left of a black box OR on the right 
						{
							flag_1 = true;
						}
						else
						{
							flag_1 = false;
							flag_2 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_1 = true;
					}
				}

				if(flag_2 == false)
				{
					break;
				}
			}


			// comparing the dimensions of the car with each tree
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if(((yI + 30) > tree_Y1[i][j]) && (yI < tree_y2[i][j])) // If the car is within the y-coordinate range
					{

						if((xI < tree_x1[i][j]) || (xI > tree_x2[i][j])) // Move the car if it is on the left of a black box OR on the right 
						{
							flag_3 = true;
						}
						else
						{
							flag_3 = false;
							flag_4 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_3 = true;
					}
				}

				if(flag_4 == false)
				{
					break;
				}
			}
			
		}

		else if ((xI + 5) > 750)
		{
			flag_3 = true;
			flag_5 = true;
		}

		// comparing the dimensions of the car with each tree
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if(((yI + 30) > pass_Y1[i][j]) && (yI < pass_y2[i][j])) // If the car is within the y-coordinate range
					{

						if((xI < pass_x1[i][j]) || (xI > pass_x2[i][j])) // Move the car if it is on the left of a black box OR on the right 
						{
							flag_5 = true;
						}
						else
						{
							flag_5 = false;
							flag_6 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_5 = true;
					}
				}

				if(flag_6 == false)
				{
					break;
				}
			}

		// If the moving condition is satisfied then move the car
		if ((flag_1 == true) && (flag_3 == true) && (flag_5 == true))
		{
			xI += 5;
			cout << xI << endl;
		}

		// If the car hits an obstacle

		if (flag_3 == false)
		{
			score = score - 4;
		}

		// If the car hits a passenger

		if (flag_5 == false)
		{
			score = score - 5;
		}
	}


	else if (key == GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) 
	{
		flag_1 = false;
		flag_2 = true;

		flag_3 = false;
		flag_4 = true;

		flag_5 = false;
		flag_6 = true;

		if(!((yI + 5) > 610)) // the car is not allowed to go out of the top line of the box
		{
			// comparing the dimensions of the car with each small box of the black track
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if((xI > x1[i][j]) && ((xI - 30) < x2[i][j])) // If the car is within the x-coordinate range
					{
						
						if(((yI + 30) < Y1[i][j]) || ((yI + 30) > y2[i][j])) // Move the car if it is on the top of a black box OR on the bottom 
						{
							
							flag_1 = true;
						}
						else
						{
							flag_1 = false;
							flag_2 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_1 = true;
					}
				}

				if(flag_2 == false)
				{
					break;
				}

				
			}


			// comparing the dimensions of the car with each small box of the tree
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if((xI > tree_x1[i][j]) && ((xI - 30) < tree_x2[i][j])) // If the car is within the x-coordinate range
					{
						if(((yI + 30) < tree_Y1[i][j]) || ((yI + 30) > tree_y2[i][j])) // Move the car if it is on the top of a tree OR on the bottom 
						{
							
							flag_3 = true;
						}
						else
						{
							flag_3 = false;
							flag_4 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_3 = true;
					}
				}

				if(flag_4 == false)
				{
					break;
				}
				
			}

			// comparing the dimensions of the car with each small box of the passenger
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{

					if((xI > pass_x1[i][j]) && ((xI - 30) < pass_x2[i][j])) // If the car is within the x-coordinate range
					{
						if(((yI + 30) < pass_Y1[i][j]) || ((yI + 30) > pass_y2[i][j])) // Move the car if it is on the top of a tree OR on the bottom 
						{
							
							flag_5 = true;
						}
						else
						{
							flag_5 = false;
							flag_6 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_5 = true;
					}
				}

				if(flag_6 == false)
				{
					break;
				}
				
			}

			
		}
		else if((yI + 5) > 610)
		{
			flag_5 = true;
			flag_3 = true;
		}

		

		// If the moving condition is satisfied then move the car
		if ((flag_1 == true) && (flag_3 == true) && (flag_5 == true))
		{
			yI += 5;
			cout << yI << endl;
		}

		// If the car collides with any tree
		
		if (flag_3 == false)
		{
			score = score - 4;
		}

		// If the car collides with any passenger
		
		if (flag_5 == false)
		{
			score = score - 5;
		}
	}

	else if (key == GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) 
	{
		flag_1 = false;
		flag_2 = true;

		flag_3 = false;
		flag_4 = true;

		flag_5 = false;
		flag_6 = true;

		if(!((yI - 5) < 40)) // the car is not allowed to go out of the bottom line of the box
		{
			// comparing the dimensions of the car with each small box of the black track
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if((xI > x1[i][j]) && ((xI - 30) < x2[i][j])) // If the car is within the x-coordinate range
					{
						
						if((yI < Y1[i][j]) || (yI > y2[i][j])) // Move the car if it is on the top of a black box OR on the bottom 
						{
							
							flag_1 = true;
						}
						else
						{
							flag_1 = false;
							flag_2 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_1 = true;
					}
				}

				if(flag_2 == false)
				{
					break;
				}

				
			}

			// comparing the dimensions of the car with each small box of the tree
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if((xI > tree_x1[i][j]) && ((xI - 30) < tree_x2[i][j])) // If the car is within the x-coordinate range
					{
						
						if((yI < tree_Y1[i][j]) || (yI > tree_y2[i][j])) // Move the car if it is on the top of a tree OR on the bottom 
						{
							
							flag_3 = true;
						}
						else
						{
							flag_3 = false;
							flag_4 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_3 = true;
					}
				}

				if(flag_4 == false)
				{
					break;
				}

				
			}


			// comparing the dimensions of the car with each small box of the passenger
			for(int i = 0 ; (i <= 19) ; i++)
			{
				for(int j = 0 ; (j <= 19) ; j++)
				{
					
					if((xI > pass_x1[i][j]) && ((xI - 30) < pass_x2[i][j])) // If the car is within the x-coordinate range
					{
						
						if((yI < pass_Y1[i][j]) || (yI > pass_y2[i][j])) // Move the car if it is on the top of a tree OR on the bottom 
						{
							
							flag_5 = true;
						}
						else
						{
							flag_5 = false;
							flag_6 = false;
							break; // If this condition is true, we break out of the 2D loop
						}
					}
					else
					{
						flag_5 = true;
					}
				}

				if(flag_6 == false)
				{
					break;
				}

				
			}

			
		}

		else if((yI - 5) < 40)
		{
			flag_3 = true;
			flag_5 = true;
		}

		

		// If the moving condition is satisfied then move the car
		if ((flag_1 == true) && (flag_3 == true) && (flag_5 == true))
		{
			yI -= 5;
			cout << yI << endl;
		}

		// If the car hits an obstacle
		
		if (flag_3 == false)
		{
			score = score - 4;
		}

		// If the car hits a passenger
		
		if (flag_5 == false)
		{
			score = score - 5;
		}
		
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}





/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {

	// implement your functionality here
	moveCar();

	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(100, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {
	//cout << x << " " << y << endl;
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{
			cout<<"Right Button Pressed"<<endl;

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	int width = 1020, height = 840; // i have set my window size to be 800 x 600

	InitPassFlag();
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("Rush Hour"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* RushHour_CPP_ */
